import mongoose from "mongoose";

const customerSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: [true, "Full name is required"], trim: true },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      select: false, // never returned unless explicitly requested
    },
    phone: { type: String, required: [true, "Phone number is required"], trim: true },

    // product ids the customer saved
    wishlist: [{ type: mongoose.Schema.Types.ObjectId, ref: "product" }],

    // one row per product, with a quantity
    cart: [
      {
        product: { type: mongoose.Schema.Types.ObjectId, ref: "product", required: true },
        quantity: { type: Number, default: 1, min: 1 },
      },
    ],
  },
  { timestamps: true }
);

export default mongoose.model("customer", customerSchema);
