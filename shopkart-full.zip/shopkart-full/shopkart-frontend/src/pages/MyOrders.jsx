import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getMyOrders } from "../services/api";
import Navbar from "../components/Navbar";

function MyOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    getMyOrders()
      .then((data) => setOrders(data.orders))
      .catch((err) => setError(err.message || "Could not load orders"))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <Navbar />
      <div className="page">
        <h2>My Orders</h2>
        {loading && <p className="page-message">Loading...</p>}
        {error && <p className="form-error">{error}</p>}

        {!loading && !error && orders.length === 0 && (
          <div className="empty-state">
            <p>You have not placed any orders yet.</p>
            <Link to="/products" className="button-link">Browse Products</Link>
          </div>
        )}

        {orders.map((order) => (
          <div key={order._id} className="order-card">
            <div className="order-head">
              <div>
                <p className="muted">Order #{order._id.slice(-8).toUpperCase()}</p>
                <p className="muted">{new Date(order.createdAt).toLocaleString("en-IN")}</p>
              </div>
              <span className="badge">{order.status}</span>
            </div>

            {order.items.map((item) => (
              <div key={item.product} className="order-line">
                <img src={item.image} alt={item.name} />
                <span className="grow">{item.name} × {item.quantity}</span>
                <span>₹{(item.price * item.quantity).toLocaleString("en-IN")}</span>
              </div>
            ))}

            <div className="summary-line total">
              <strong>Total</strong>
              <strong>₹{order.totalAmount.toLocaleString("en-IN")}</strong>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default MyOrders;
