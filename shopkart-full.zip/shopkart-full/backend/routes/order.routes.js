import express from "express";
import authMiddleware from "../middlewares/auth.middleware.js";
import {
  createPaymentOrder,
  verifyPayment,
  getMyOrders,
  getOrderById,
} from "../controllers/order.controller.js";

const orderRouter = express.Router();

orderRouter.use(authMiddleware);
orderRouter.post("/create-payment-order", createPaymentOrder);
orderRouter.post("/verify-payment", verifyPayment);
orderRouter.get("/", getMyOrders);
orderRouter.get("/:id", getOrderById);

export default orderRouter;
