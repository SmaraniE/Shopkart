import { useEffect, useState } from "react";
import { getAllProducts } from "../services/api";
import Navbar from "../components/Navbar";
import ProductCard from "../components/ProductCard";
import SearchBar from "../components/SearchBar";

function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [sort, setSort] = useState("");

  useEffect(() => {
    let ignore = false; // drop out-of-date responses while the user is still typing

    const timer = setTimeout(async () => {
      setLoading(true);
      setError(false);
      try {
        const data = await getAllProducts({
          search: search || undefined,
          category: category || undefined,
          sort: sort || undefined,
        });
        if (!ignore) setProducts(data.products);
      } catch {
        if (!ignore) setError(true);
      } finally {
        if (!ignore) setLoading(false);
      }
    }, 300); // debounce: wait 300ms after the last keystroke

    return () => {
      ignore = true;
      clearTimeout(timer);
    };
  }, [search, category, sort]);

  return (
    <div>
      <Navbar />
      <div className="page">
        <h2>Products</h2>
        <SearchBar
          search={search}
          setSearch={setSearch}
          category={category}
          setCategory={setCategory}
          sort={sort}
          setSort={setSort}
        />
        {loading && <p className="page-message">Loading products...</p>}
        {!loading && error && <p className="form-error">Something went wrong while loading products.</p>}
        {!loading && !error && products.length === 0 && <p className="page-message">No products found.</p>}
        {!loading && !error && products.length > 0 && (
          <div className="product-grid">
            {products.map((product) => (
              <ProductCard key={product._id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Products;
