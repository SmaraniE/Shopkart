import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:3000",
  withCredentials: true, // send the HttpOnly auth cookie with every request
});

// Runs a request and always throws a plain { message } object on failure,
// so pages can just show err.message.
const request = async (config) => {
  try {
    const response = await api(config);
    return response.data;
  } catch (error) {
    throw error.response?.data || { message: "Cannot reach the server. Is the backend running?" };
  }
};

// ---- customers ----
export const registerCustomer = (data) => request({ method: "post", url: "/customers/register", data });
export const loginCustomer = (data) => request({ method: "post", url: "/customers/login", data });
export const getCurrentCustomer = () => request({ method: "get", url: "/customers/me" });
export const logoutCustomer = () => request({ method: "post", url: "/customers/logout" });

// ---- products ----
export const getAllProducts = (params) => request({ method: "get", url: "/products", params });
export const getProductById = (id) => request({ method: "get", url: `/products/${id}` });

// ---- wishlist ----
export const getWishlist = () => request({ method: "get", url: "/wishlist" });
export const addToWishlist = (productId) => request({ method: "post", url: `/wishlist/${productId}` });
export const removeFromWishlist = (productId) => request({ method: "delete", url: `/wishlist/${productId}` });

// ---- cart ----
export const getCart = () => request({ method: "get", url: "/cart" });
export const addToCart = (productId) => request({ method: "post", url: `/cart/${productId}` });
export const updateCartQuantity = (productId, quantity) =>
  request({ method: "patch", url: `/cart/${productId}`, data: { quantity } });
export const removeFromCart = (productId) => request({ method: "delete", url: `/cart/${productId}` });

// ---- orders ----
export const createPaymentOrder = (shippingAddress) =>
  request({ method: "post", url: "/orders/create-payment-order", data: { shippingAddress } });
export const verifyPayment = (data) => request({ method: "post", url: "/orders/verify-payment", data });
export const getMyOrders = () => request({ method: "get", url: "/orders" });
export const getOrderById = (id) => request({ method: "get", url: `/orders/${id}` });
