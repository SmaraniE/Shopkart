import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import Navbar from "../components/Navbar";

function Cart() {
  const navigate = useNavigate();
  const { items, loading, error, cartCount, subtotal, fetchCart, updateQuantity, removeItem } = useCart();
  const [actionError, setActionError] = useState("");
  const [busyId, setBusyId] = useState(null); // which row is being changed

  // always fetch fresh data when the page opens, so latest price and stock show
  useEffect(() => {
    fetchCart();
  }, [fetchCart]);

  const run = async (productId, action) => {
    setActionError("");
    setBusyId(productId);
    try {
      await action();
    } catch (err) {
      setActionError(err.message || "Something went wrong");
    } finally {
      setBusyId(null);
    }
  };

  // skip rows whose product was deleted from the database
  const rows = items.filter((row) => row.product);

  return (
    <div>
      <Navbar />
      <div className="page">
        <h2>My Cart</h2>

        {loading && <p className="page-message">Loading your cart...</p>}

        {!loading && error && rows.length === 0 && (
          <div className="empty-state">
            <p>Unable to load your cart.</p>
            <button onClick={fetchCart}>Try Again</button>
          </div>
        )}

        {!loading && !error && rows.length === 0 && (
          <div className="empty-state">
            <p>Your cart is empty 🛒</p>
            <button onClick={() => navigate("/products")}>Browse Products</button>
          </div>
        )}

        {!loading && rows.length > 0 && (
          <div className="cart-layout">
            <div className="cart-items">
              {actionError && <p className="form-error">{actionError}</p>}
              {rows.map((row) => {
                const p = row.product;
                const busy = busyId === p._id;
                return (
                  <div className="cart-item" key={p._id}>
                    <img src={p.image} alt={p.name} />
                    <div className="cart-item-info">
                      <h3>{p.name}</h3>
                      <p className="product-price">₹{p.price.toLocaleString("en-IN")}</p>
                      <div className="quantity-controls">
                        <button
                          className="btn-secondary"
                          disabled={row.quantity <= 1 || busy}
                          onClick={() => run(p._id, () => updateQuantity(p._id, row.quantity - 1))}
                        >
                          −
                        </button>
                        <span>{busy ? "..." : row.quantity}</span>
                        <button
                          className="btn-secondary"
                          disabled={row.quantity >= p.stock || busy}
                          onClick={() => run(p._id, () => updateQuantity(p._id, row.quantity + 1))}
                        >
                          +
                        </button>
                      </div>
                      <button className="btn-danger" disabled={busy} onClick={() => run(p._id, () => removeItem(p._id))}>
                        Remove
                      </button>
                    </div>
                    <p className="cart-line-total">₹{(p.price * row.quantity).toLocaleString("en-IN")}</p>
                  </div>
                );
              })}
            </div>

            <div className="order-summary">
              <h3>Order Summary</h3>
              <p>Items: {cartCount}</p>
              <p>Subtotal: <strong>₹{subtotal.toLocaleString("en-IN")}</strong></p>
              <button onClick={() => navigate("/checkout")}>Proceed to Checkout</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default Cart;
