import express from "express";
import authMiddleware from "../middlewares/auth.middleware.js";
import { createProduct, getAllProducts, getProductById } from "../controllers/product.controller.js";

const productRouter = express.Router();

productRouter.get("/", getAllProducts);
productRouter.get("/:id", getProductById);
productRouter.post("/", authMiddleware, createProduct);

export default productRouter;
