import jwt from "jsonwebtoken";

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

// Shared by login (res.cookie) and logout (res.clearCookie).
// clearCookie only works if the options match the ones used to set the cookie.
export const cookieOptions = {
  httpOnly: true, // JavaScript in the browser cannot read this cookie (blocks XSS token theft)
  sameSite: "strict", // cookie is not sent on cross-site requests (helps against CSRF)
  secure: process.env.NODE_ENV === "production", // HTTPS only in production
};

export const cookieMaxAge = SEVEN_DAYS_MS;

const generateToken = (id) => {
  // Payload holds only the customer id - never put passwords or secrets in a JWT.
  return jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: "7d" });
};

export default generateToken;
