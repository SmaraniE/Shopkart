import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { getOrderById } from "../services/api";
import Navbar from "../components/Navbar";

function OrderSuccess() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getOrderById(id)
      .then((data) => setOrder(data.order))
      .catch((err) => setError(err.message || "Could not load order"));
  }, [id]);

  return (
    <div>
      <Navbar />
      <div className="page narrow">
        {error && <p className="form-error">{error}</p>}
        {!error && !order && <p className="page-message">Loading...</p>}

        {order && (
          <div className="success-card">
            <div className="tick">✓</div>
            <h2>Order placed successfully!</h2>
            <p className="muted">Order ID: {order._id}</p>

            <div className="summary-block">
              {order.items.map((item) => (
                <div key={item.product} className="summary-line">
                  <span>{item.name} × {item.quantity}</span>
                  <span>₹{(item.price * item.quantity).toLocaleString("en-IN")}</span>
                </div>
              ))}
              <hr />
              <div className="summary-line">
                <strong>Total paid</strong>
                <strong>₹{order.totalAmount.toLocaleString("en-IN")}</strong>
              </div>
            </div>

            <div className="summary-block">
              <h4>Shipping to</h4>
              <p>{order.shippingAddress.fullName} ({order.shippingAddress.phone})</p>
              <p>
                {order.shippingAddress.addressLine1}, {order.shippingAddress.city},{" "}
                {order.shippingAddress.state} - {order.shippingAddress.pincode}
              </p>
            </div>

            <div className="card-actions center">
              <Link to="/orders" className="button-link">View My Orders</Link>
              <Link to="/products" className="button-link secondary">Continue Shopping</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default OrderSuccess;
