import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getWishlist, removeFromWishlist } from "../services/api";
import Navbar from "../components/Navbar";
import WishlistCard from "../components/WishlistCard";

function Wishlist() {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    getWishlist()
      .then((data) => setProducts(data.wishlist))
      .catch((err) => setError(err.message || "Could not load wishlist"))
      .finally(() => setLoading(false));
  }, []);

  const handleRemove = async (productId) => {
    setError("");
    try {
      await removeFromWishlist(productId);
      setProducts((prev) => prev.filter((p) => p._id !== productId));
    } catch (err) {
      setError(err.message || "Could not remove item");
    }
  };

  return (
    <div>
      <Navbar />
      <div className="page">
        <h2>My Wishlist</h2>
        {loading && <p className="page-message">Loading...</p>}
        {error && <p className="form-error">{error}</p>}
        {!loading && products.length === 0 && (
          <div className="empty-state">
            <p>Your wishlist is empty.</p>
            <button onClick={() => navigate("/products")}>Browse Products</button>
          </div>
        )}
        {!loading && products.length > 0 && (
          <div className="product-grid">
            {products.map((product) => (
              <WishlistCard key={product._id} product={product} onRemove={handleRemove} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default Wishlist;
