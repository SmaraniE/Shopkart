import express from "express";
import authMiddleware from "../middlewares/auth.middleware.js";
import { addToWishlist, getWishlist, removeFromWishlist } from "../controllers/wishlist.controller.js";

const wishlistRouter = express.Router();

wishlistRouter.use(authMiddleware); // every wishlist route needs a logged-in customer
wishlistRouter.get("/", getWishlist);
wishlistRouter.post("/:productId", addToWishlist);
wishlistRouter.delete("/:productId", removeFromWishlist);

export default wishlistRouter;
