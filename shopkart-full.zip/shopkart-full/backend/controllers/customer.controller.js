import bcrypt from "bcrypt";
import Customer from "../models/customer.model.js";
import generateToken, {
  cookieOptions,
  cookieMaxAge,
} from "../utils/generateToken.js";

// Only these fields are ever sent back to the client
const toCustomerResponse = (customer) => ({
  _id: customer._id,
  fullName: customer.fullName,
  email: customer.email,
  phone: customer.phone,
});

const isNonEmptyString = (value) =>
  typeof value === "string" && value.trim().length > 0;

// POST /customers/register
export const registerCustomer = async (req, res) => {
  try {
    const { fullName, email, password, phone } = req.body || {};

    if (
      !isNonEmptyString(fullName) ||
      !isNonEmptyString(email) ||
      !isNonEmptyString(password) ||
      !isNonEmptyString(phone)
    ) {
      return res
        .status(400)
        .json({ success: false, message: "All fields are required" });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: "Password must be at least 6 characters long",
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    const emailExists = await Customer.findOne({ email: normalizedEmail });
    if (emailExists) {
      return res
        .status(409)
        .json({ success: false, message: "Email already exists" });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newCustomer = await Customer.create({
      fullName: fullName.trim(),
      email: normalizedEmail,
      password: hashedPassword,
      phone: phone.trim(),
    });

    res.status(201).json({
      success: true,
      message: "Customer registered successfully",
      customer: toCustomerResponse(newCustomer),
    });
  } catch (error) {
    // Two requests with the same email at the same time can both pass the
    // findOne check; the unique index then rejects the second one (code 11000).
    if (error.code === 11000) {
      return res
        .status(409)
        .json({ success: false, message: "Email already exists" });
    }
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// POST /customers/login
export const loginCustomer = async (req, res) => {
  try {
    const { email, password } = req.body || {};

    if (!isNonEmptyString(email) || !isNonEmptyString(password)) {
      return res.status(400).json({
        success: false,
        message: "Email and password are required",
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    // password has select: false, so we must ask for it explicitly here
    const customer = await Customer.findOne({ email: normalizedEmail }).select(
      "+password"
    );

    // Same message + status for "no such email" and "wrong password",
    // so an attacker cannot find out which emails are registered.
    if (!customer) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, customer.password);
    if (!isMatch) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid credentials" });
    }

    const token = generateToken(customer._id);

    res.cookie("token", token, { ...cookieOptions, maxAge: cookieMaxAge });

    res.status(200).json({
      success: true,
      message: "Login successful",
      customer: toCustomerResponse(customer),
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// GET /customers/me  (protected)
export const getProfile = async (req, res) => {
  res.status(200).json(toCustomerResponse(req.user));
};

// POST /customers/logout  (protected)
export const logoutCustomer = async (req, res) => {
  res.clearCookie("token", cookieOptions);
  res.status(200).json({
    success: true,
    message: "Logged out successfully",
  });
};

// PATCH /customers/change-password  (protected) - bonus
export const changePassword = async (req, res) => {
  try {
    const { oldPassword, newPassword } = req.body || {};

    if (!isNonEmptyString(oldPassword) || !isNonEmptyString(newPassword)) {
      return res.status(400).json({
        success: false,
        message: "Old password and new password are required",
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: "New password must be at least 6 characters long",
      });
    }

    // req.user has no password field, so load it again with the hash
    const customer = await Customer.findById(req.user._id).select("+password");

    const isMatch = await bcrypt.compare(oldPassword, customer.password);
    if (!isMatch) {
      return res
        .status(401)
        .json({ success: false, message: "Old password is incorrect" });
    }

    if (oldPassword === newPassword) {
      return res.status(400).json({
        success: false,
        message: "New password must be different from the old password",
      });
    }

    const salt = await bcrypt.genSalt(10);
    customer.password = await bcrypt.hash(newPassword, salt);
    await customer.save();

    res.status(200).json({
      success: true,
      message: "Password changed successfully",
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};
