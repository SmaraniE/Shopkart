import express from "express";
import authMiddleware from "../middlewares/auth.middleware.js";
import { addToCart, getCart, updateCartQuantity, removeFromCart } from "../controllers/cart.controller.js";

const cartRouter = express.Router();

cartRouter.use(authMiddleware);
cartRouter.get("/", getCart);
cartRouter.post("/:productId", addToCart);
cartRouter.patch("/:productId", updateCartQuantity);
cartRouter.delete("/:productId", removeFromCart);

export default cartRouter;
