import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { addToWishlist } from "../services/api";
import { useCart } from "../context/CartContext";

function ProductCard({ product }) {
  const navigate = useNavigate();
  const { items, addItem } = useCart();
  const [wishlistState, setWishlistState] = useState("default"); // default | saving | success | error
  const [adding, setAdding] = useState(false);
  const [message, setMessage] = useState("");

  const inCart = items.some((row) => row.product?._id === product._id);

  const handleWishlist = async () => {
    if (wishlistState === "saving" || wishlistState === "success") return;
    setWishlistState("saving");
    try {
      await addToWishlist(product._id);
      setWishlistState("success");
    } catch (err) {
      // 409 means it is already saved, which is fine
      setWishlistState(err.message === "Product already in wishlist" ? "success" : "error");
    }
  };

  const handleAddToCart = async () => {
    if (adding) return;
    setAdding(true);
    setMessage("");
    try {
      await addItem(product._id);
    } catch (err) {
      setMessage(err.message || "Could not add to cart.");
    } finally {
      setAdding(false);
    }
  };

  const wishlistLabel = {
    default: "♡ Add to Wishlist",
    saving: "Saving...",
    success: "♥ In Wishlist",
    error: "Failed. Try again",
  }[wishlistState];

  return (
    <div className="product-card">
      <img src={product.image} alt={product.name} onClick={() => navigate(`/products/${product._id}`)} />
      <h3>{product.name}</h3>
      <p className="product-category">{product.category}</p>
      <p className="product-price">₹{product.price.toLocaleString("en-IN")}</p>
      <p className={product.stock > 0 ? "product-stock" : "product-stock out"}>
        {product.stock > 0 ? `${product.stock} units left` : "Out of stock"}
      </p>
      <div className="card-actions">
        <button className="btn-secondary" onClick={() => navigate(`/products/${product._id}`)}>
          View Details
        </button>
        <button className="btn-secondary" onClick={handleWishlist} disabled={wishlistState === "saving"}>
          {wishlistLabel}
        </button>
        <button onClick={handleAddToCart} disabled={adding || product.stock < 1}>
          {adding ? "Adding..." : inCart ? "Add Another" : "Add to Cart"}
        </button>
      </div>
      {message && <p className="form-error">{message}</p>}
    </div>
  );
}

export default ProductCard;
