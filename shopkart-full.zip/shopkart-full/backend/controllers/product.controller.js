import mongoose from "mongoose";
import Product from "../models/product.model.js";

const escapeRegex = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// POST /products  (protected)
export const createProduct = async (req, res) => {
  try {
    const { name, description, price, category, image, stock } = req.body || {};

    if (!name || !description || !category || !image) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }
    if (typeof price !== "number" || price <= 0) {
      return res.status(400).json({ success: false, message: "Price must be greater than 0" });
    }
    if (typeof stock !== "number" || stock < 0) {
      return res.status(400).json({ success: false, message: "Stock cannot be negative" });
    }

    const product = await Product.create({ name, description, price, category, image, stock });
    res.status(201).json({ success: true, message: "Product created successfully", product });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// GET /products?search=&category=&sort=price_asc|price_desc
export const getAllProducts = async (req, res) => {
  try {
    const { search, category, sort } = req.query;
    const filter = {};

    if (typeof search === "string" && search.trim()) {
      // escape user input so characters like "(" can't break the regex
      filter.name = { $regex: escapeRegex(search.trim()), $options: "i" };
    }
    if (typeof category === "string" && category) filter.category = category;

    let query = Product.find(filter).select("name price category image stock");
    if (sort === "price_asc") query = query.sort({ price: 1 });
    else if (sort === "price_desc") query = query.sort({ price: -1 });
    else query = query.sort({ createdAt: -1 });

    const products = await query;
    res.status(200).json({ success: true, count: products.length, products });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// GET /products/:id
export const getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: "Invalid product ID" });
    }
    const product = await Product.findById(id);
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }
    res.status(200).json({ success: true, product });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};
