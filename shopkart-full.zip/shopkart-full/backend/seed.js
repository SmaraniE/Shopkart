// Fills the database with sample products:  npm run seed   (add -- --reset to replace existing ones)
import dns from "dns";
dns.setServers(["8.8.8.8", "8.8.4.4"]);

import mongoose from "mongoose";
import Product from "./models/product.model.js";

const img = (seed) => `https://picsum.photos/seed/${seed}/600/450`;

const products = [
  { name: "Wireless Headphones", category: "Electronics", price: 2999, stock: 25, image: img("headphones"), description: "Over-ear Bluetooth headphones with 30-hour battery life and deep bass." },
  { name: "Smart Watch", category: "Electronics", price: 4499, stock: 15, image: img("smartwatch"), description: "Fitness tracking, heart-rate monitor and sleep tracking with a bright AMOLED display." },
  { name: "Bluetooth Speaker", category: "Electronics", price: 1899, stock: 30, image: img("speaker"), description: "Portable waterproof speaker with 12 hours of playtime." },
  { name: "Power Bank 20000mAh", category: "Electronics", price: 1599, stock: 40, image: img("powerbank"), description: "Fast-charging power bank with dual USB output." },
  { name: "Cotton T-Shirt", category: "Fashion", price: 599, stock: 60, image: img("tshirt"), description: "Soft, breathable 100% cotton t-shirt in a regular fit." },
  { name: "Denim Jacket", category: "Fashion", price: 2199, stock: 12, image: img("jacket"), description: "Classic denim jacket with a comfortable relaxed fit." },
  { name: "Running Shoes", category: "Fashion", price: 3299, stock: 20, image: img("shoes"), description: "Lightweight running shoes with cushioned soles and breathable mesh." },
  { name: "Backpack", category: "Fashion", price: 1299, stock: 35, image: img("backpack"), description: "Water-resistant 25L backpack with a padded laptop compartment." },
  { name: "Atomic Habits", category: "Books", price: 499, stock: 50, image: img("book1"), description: "A practical guide to building good habits and breaking bad ones." },
  { name: "The Pragmatic Programmer", category: "Books", price: 899, stock: 18, image: img("book2"), description: "Classic advice on becoming a better, more effective software developer." },
  { name: "Ceramic Coffee Mug Set", category: "Home", price: 799, stock: 45, image: img("mugs"), description: "Set of 4 microwave-safe ceramic mugs." },
  { name: "LED Desk Lamp", category: "Home", price: 1099, stock: 0, image: img("lamp"), description: "Adjustable LED desk lamp with three brightness levels." },
];

await mongoose.connect(process.env.MONGO_URI);

const existing = await Product.countDocuments();
if (existing > 0 && !process.argv.includes("--reset")) {
  console.log(`${existing} products already exist. Run "npm run seed -- --reset" to replace them.`);
} else {
  await Product.deleteMany({});
  await Product.insertMany(products);
  console.log(`Seeded ${products.length} products`);
}

await mongoose.disconnect();
