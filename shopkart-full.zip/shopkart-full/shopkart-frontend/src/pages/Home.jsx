import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getCurrentCustomer } from "../services/api";
import Navbar from "../components/Navbar";

function Home() {
  const [customer, setCustomer] = useState(null);

  useEffect(() => {
    getCurrentCustomer().then(setCustomer).catch(() => {});
  }, []);

  return (
    <div>
      <Navbar />
      <div className="page">
        {customer && (
          <div className="profile-card">
            <h2>Welcome, {customer.fullName}</h2>
            <p>Email: {customer.email}</p>
            <p>Phone: {customer.phone}</p>
            <Link to="/products" className="button-link">Start shopping</Link>
          </div>
        )}
      </div>
    </div>
  );
}

export default Home;
