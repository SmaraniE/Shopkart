import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getProductById, addToWishlist } from "../services/api";
import { useCart } from "../context/CartContext";
import Navbar from "../components/Navbar";

function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addItem } = useCart();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    setLoading(true);
    getProductById(id)
      .then((data) => setProduct(data.product))
      .catch((err) => setError(err.message || "Could not load product"))
      .finally(() => setLoading(false));
  }, [id]);

  const handleAddToCart = async () => {
    setNotice("");
    try {
      await addItem(product._id);
      setNotice("Added to cart");
    } catch (err) {
      setNotice(err.message || "Could not add to cart");
    }
  };

  const handleWishlist = async () => {
    setNotice("");
    try {
      await addToWishlist(product._id);
      setNotice("Added to wishlist");
    } catch (err) {
      setNotice(err.message || "Could not add to wishlist");
    }
  };

  return (
    <div>
      <Navbar />
      <div className="page">
        <button className="btn-secondary" onClick={() => navigate(-1)}>← Back</button>
        {loading && <p className="page-message">Loading...</p>}
        {!loading && error && <p className="form-error">{error}</p>}
        {!loading && product && (
          <div className="details">
            <img src={product.image} alt={product.name} />
            <div className="details-info">
              <h2>{product.name}</h2>
              <p className="product-category">{product.category}</p>
              <p className="details-price">₹{product.price.toLocaleString("en-IN")}</p>
              <p>{product.description}</p>
              <p className={product.stock > 0 ? "product-stock" : "product-stock out"}>
                {product.stock > 0 ? `${product.stock} units in stock` : "Out of stock"}
              </p>
              <div className="card-actions">
                <button onClick={handleAddToCart} disabled={product.stock < 1}>Add to Cart</button>
                <button className="btn-secondary" onClick={handleWishlist}>♡ Add to Wishlist</button>
              </div>
              {notice && <p className="notice">{notice}</p>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default ProductDetails;
