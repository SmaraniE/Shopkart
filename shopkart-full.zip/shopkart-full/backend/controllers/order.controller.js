import crypto from "crypto";
import mongoose from "mongoose";
import Razorpay from "razorpay";
import Product from "../models/product.model.js";
import Customer from "../models/customer.model.js";
import Order from "../models/order.model.js";

const getRazorpay = () =>
  new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID,
    key_secret: process.env.RAZORPAY_KEY_SECRET,
  });

const ADDRESS_FIELDS = ["fullName", "phone", "addressLine1", "city", "state", "pincode"];

// returns an error message, or null when the address is valid
const validateShippingAddress = (address) => {
  if (!address || typeof address !== "object") return "Shipping address is required";
  for (const field of ADDRESS_FIELDS) {
    if (typeof address[field] !== "string" || !address[field].trim()) {
      return `${field} is required`;
    }
  }
  if (!/^[0-9]{10}$/.test(address.phone.trim())) return "Phone must be exactly 10 digits";
  if (!/^[0-9]{6}$/.test(address.pincode.trim())) return "Pincode must be exactly 6 digits";
  return null;
};

// POST /orders/create-payment-order
// Builds the order from the SERVER-side cart, so the client can never choose the price.
export const createPaymentOrder = async (req, res) => {
  try {
    const { shippingAddress } = req.body || {};

    const addressError = validateShippingAddress(shippingAddress);
    if (addressError) {
      return res.status(400).json({ success: false, message: addressError });
    }

    const customer = await Customer.findById(req.user._id).populate("cart.product");
    if (!customer.cart.length) {
      return res.status(400).json({ success: false, message: "Cart is empty" });
    }

    const items = [];
    let totalAmount = 0;

    for (const row of customer.cart) {
      const product = row.product;
      if (!product) {
        return res
          .status(400)
          .json({ success: false, message: "A product in your cart is no longer available" });
      }
      if (product.stock < row.quantity) {
        return res
          .status(400)
          .json({ success: false, message: `Insufficient stock for ${product.name}` });
      }
      items.push({
        product: product._id,
        name: product.name,
        price: product.price,
        quantity: row.quantity,
        image: product.image,
      });
      totalAmount += product.price * row.quantity;
    }

    totalAmount = Math.round(totalAmount * 100) / 100; // remove floating point noise

    const address = {};
    for (const field of ADDRESS_FIELDS) address[field] = shippingAddress[field].trim();

    const order = await Order.create({
      user: req.user._id,
      items,
      shippingAddress: address,
      totalAmount,
    });

    // Razorpay amounts are in paise (1 rupee = 100 paise)
    const razorpayOrder = await getRazorpay().orders.create({
      amount: Math.round(totalAmount * 100),
      currency: "INR",
      receipt: order._id.toString(),
    });

    order.razorpayOrderId = razorpayOrder.id;
    await order.save();

    res.status(201).json({
      orderId: order._id,
      razorpayOrderId: razorpayOrder.id,
      amount: razorpayOrder.amount,
      currency: razorpayOrder.currency,
      keyId: process.env.RAZORPAY_KEY_ID,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not create payment order" });
  }
};

// POST /orders/verify-payment
// Never trust the browser saying "payment done": recompute the signature with our secret.
export const verifyPayment = async (req, res) => {
  try {
    const { orderId, razorpay_order_id, razorpay_payment_id, razorpay_signature } =
      req.body || {};

    if (!orderId || !razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ success: false, message: "Missing payment details" });
    }
    if (!mongoose.Types.ObjectId.isValid(orderId)) {
      return res.status(400).json({ success: false, message: "Invalid order ID" });
    }

    // user filter: only the owner can verify their own order
    const order = await Order.findOne({ _id: orderId, user: req.user._id });
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found" });
    }

    if (order.paymentStatus === "PAID") {
      return res
        .status(200)
        .json({ success: true, message: "Payment already verified", orderId: order._id });
    }
    if (order.razorpayOrderId !== razorpay_order_id) {
      return res
        .status(400)
        .json({ success: false, message: "Razorpay order does not match this order" });
    }

    const expected = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest("hex");

    const valid =
      typeof razorpay_signature === "string" &&
      expected.length === razorpay_signature.length &&
      crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(razorpay_signature));

    if (!valid) {
      order.paymentStatus = "FAILED";
      await order.save();
      return res.status(400).json({ success: false, message: "Payment verification failed" });
    }

    // Signature is genuine: reduce stock, but only where enough is still left
    for (const item of order.items) {
      await Product.updateOne(
        { _id: item.product, stock: { $gte: item.quantity } },
        { $inc: { stock: -item.quantity } }
      );
    }

    order.paymentStatus = "PAID";
    order.status = "PLACED";
    order.razorpayPaymentId = razorpay_payment_id;
    await order.save();

    // clear the cart only after a verified payment
    await Customer.findByIdAndUpdate(req.user._id, { cart: [] });

    res
      .status(200)
      .json({ success: true, message: "Payment verified. Order placed", orderId: order._id });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not verify payment" });
  }
};

// GET /orders  - only paid orders, so abandoned checkouts don't clutter the list
export const getMyOrders = async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id, paymentStatus: "PAID" }).sort({
      createdAt: -1,
    });
    res.status(200).json({ success: true, orders });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not fetch orders" });
  }
};

// GET /orders/:id
export const getOrderById = async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ success: false, message: "Invalid order ID" });
    }
    const order = await Order.findOne({ _id: id, user: req.user._id });
    if (!order) {
      return res.status(404).json({ success: false, message: "Order not found" });
    }
    res.status(200).json({ success: true, order });
  } catch (error) {
    res.status(500).json({ success: false, message: "Could not fetch order" });
  }
};
