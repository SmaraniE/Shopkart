import { Link, NavLink, useNavigate } from "react-router-dom";
import { logoutCustomer } from "../services/api";
import { useCart } from "../context/CartContext";

function Navbar() {
  const navigate = useNavigate();
  const { cartCount, clearCart } = useCart();

  const handleLogout = async () => {
    try {
      await logoutCustomer();
    } finally {
      clearCart();
      navigate("/login");
    }
  };

  return (
    <nav className="navbar">
      <Link to="/home" className="brand">ShopKart</Link>
      <div className="nav-links">
        <NavLink to="/products">Products</NavLink>
        <NavLink to="/wishlist">Wishlist</NavLink>
        <NavLink to="/cart">Cart ({cartCount})</NavLink>
        <NavLink to="/orders">Orders</NavLink>
        <button className="btn-link" onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );
}

export default Navbar;
