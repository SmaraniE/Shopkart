import { useEffect, useState } from "react";
import { Navigate, Outlet } from "react-router-dom";
import { getCurrentCustomer } from "../services/api";

// Asks the backend "who am I?" once. 401 -> send to /login.
function ProtectedRoute() {
  const [status, setStatus] = useState("checking"); // checking | ok | denied

  useEffect(() => {
    getCurrentCustomer()
      .then(() => setStatus("ok"))
      .catch(() => setStatus("denied"));
  }, []);

  if (status === "checking") return <p className="page-message">Loading...</p>;
  if (status === "denied") return <Navigate to="/login" replace />;
  return <Outlet />;
}

export default ProtectedRoute;
