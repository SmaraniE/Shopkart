import jwt from "jsonwebtoken";
import Customer from "../models/customer.model.js";

// Decides whether a request may continue to the controller.
const authMiddleware = async (req, res, next) => {
  try {
    const token = req.cookies?.token;

    if (!token) {
      return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    // Throws if the token is tampered with or expired
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const customer = await Customer.findById(decoded.id);

    if (!customer) {
      return res.status(401).json({ success: false, message: "Unauthorized" });
    }

    req.user = customer; // password is excluded because of select: false
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: "Unauthorized" });
  }
};

export default authMiddleware;
