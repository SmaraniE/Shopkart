import mongoose from "mongoose";
import Product from "../models/product.model.js";
import Customer from "../models/customer.model.js";

// POST /cart/:productId  - adds 1 unit (or creates the row)
export const addToCart = async (req, res) => {
  try {
    const { productId } = req.params;
    const customer = req.user;

    if (!mongoose.Types.ObjectId.isValid(productId)) {
      return res.status(400).json({ success: false, message: "Invalid product ID" });
    }
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }

    const existing = customer.cart.find((row) => row.product.toString() === productId);

    if (existing) {
      if (existing.quantity + 1 > product.stock) {
        return res.status(400).json({ success: false, message: "Not enough stock available" });
      }
      existing.quantity += 1;
    } else {
      if (product.stock < 1) {
        return res.status(400).json({ success: false, message: "Not enough stock available" });
      }
      customer.cart.push({ product: productId, quantity: 1 });
    }

    await customer.save();
    res.status(200).json({ success: true, message: "Cart updated", cart: customer.cart });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// GET /cart
export const getCart = async (req, res) => {
  try {
    const customer = await Customer.findById(req.user._id).populate({
      path: "cart.product",
      select: "name price image stock",
    });
    res.status(200).json({ success: true, cart: customer.cart });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// PATCH /cart/:productId  body: { quantity }
export const updateCartQuantity = async (req, res) => {
  try {
    const { productId } = req.params;
    const { quantity } = req.body || {};
    const customer = req.user;

    if (!mongoose.Types.ObjectId.isValid(productId)) {
      return res.status(400).json({ success: false, message: "Invalid product ID" });
    }
    if (!Number.isInteger(quantity) || quantity < 1) {
      return res.status(400).json({ success: false, message: "Quantity must be at least 1" });
    }

    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: "Product not found" });
    }
    const row = customer.cart.find((r) => r.product.toString() === productId);
    if (!row) {
      return res.status(404).json({ success: false, message: "Product not found in cart" });
    }
    if (quantity > product.stock) {
      return res.status(400).json({ success: false, message: "Quantity exceeds available stock" });
    }

    row.quantity = quantity;
    await customer.save();
    res.status(200).json({ success: true, message: "Cart updated", cart: customer.cart });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// DELETE /cart/:productId
export const removeFromCart = async (req, res) => {
  try {
    const { productId } = req.params;
    const customer = req.user;

    if (!mongoose.Types.ObjectId.isValid(productId)) {
      return res.status(400).json({ success: false, message: "Invalid product ID" });
    }

    customer.cart = customer.cart.filter((row) => row.product.toString() !== productId);
    await customer.save();
    res.status(200).json({ success: true, message: "Product removed from cart", cart: customer.cart });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};
