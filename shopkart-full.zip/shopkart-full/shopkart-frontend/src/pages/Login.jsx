import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginCustomer } from "../services/api";
import { useCart } from "../context/CartContext";

function Login() {
  const navigate = useNavigate();
  const { fetchCart } = useCart();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setSubmitting(true);
    try {
      await loginCustomer({ email, password });
      await fetchCart(); // load this customer's saved cart
      navigate("/home");
    } catch (err) {
      setError(err.message || "Invalid credentials");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h2>Welcome back</h2>
        <form onSubmit={handleLogin}>
          <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
          {error && <p className="form-error">{error}</p>}
          <button type="submit" disabled={submitting}>{submitting ? "Logging in..." : "Login"}</button>
        </form>
        <p className="auth-switch">
          New to ShopKart? <Link to="/register">Register</Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
